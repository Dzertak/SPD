package entities;

public class Publication {


}
